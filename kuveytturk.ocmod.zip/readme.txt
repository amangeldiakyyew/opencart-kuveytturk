1) 3D ödeme yöntemini desteklemektedir
2) Test Edilen Sürüm:  3.0.3.8


Test bilgileri: 
$MerchantId = "496";
$CustomerId = "400235"; 
$UserName="apitest"; 
$Password="api123"; 

Test Card:
Kart No: #4025903160410013#
CVV: 123
Expirydate: 07/20
